import tkinter.font as tkFont

FONT_COLOR = "#000000"
BAD_COLOR = "#B00020"
COLOR = "#F0F0F0"
BG = "#FFF"
DISCORD ="#36393f"
HEIGHT = 616
WIDTH = 360


def FONT16(): return tkFont.Font(family='Arial', size=16)


def FONT12(): return tkFont.Font(family='Arial', size=12)


def FONT10(): return tkFont.Font(family='Arial', size=10)
